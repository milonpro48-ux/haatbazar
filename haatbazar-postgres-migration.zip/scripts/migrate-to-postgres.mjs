#!/usr/bin/env node
// One-time migration: converts server.js (SQLite, better-sqlite3) to PostgreSQL (Neon).
// Usage (from the project root):  node scripts/migrate-to-postgres.mjs
// It keeps a backup copy: server.js.sqlite-backup
import fs from 'node:fs';
import { spawnSync } from 'node:child_process';
import { pathToFileURL } from 'node:url';

// ---------- tiny JS scanner: skip strings / templates / balanced brackets ----------
function skipString(s, i) {
  const q = s[i]; i++;
  while (i < s.length) { const c = s[i]; if (c === '\\') { i += 2; continue; } if (c === q) return i + 1; i++; }
  throw new Error('unterminated string');
}
function skipTemplate(s, i) {
  i++;
  while (i < s.length) {
    const c = s[i];
    if (c === '\\') { i += 2; continue; }
    if (c === '`') return i + 1;
    if (c === '$' && s[i + 1] === '{') { i = skipGroup(s, i + 1, '{', '}'); continue; }
    i++;
  }
  throw new Error('unterminated template');
}
function skipGroup(s, i, open, close) {
  let depth = 0;
  while (i < s.length) {
    const c = s[i];
    if (c === "'" || c === '"') { i = skipString(s, i); continue; }
    if (c === '`') { i = skipTemplate(s, i); continue; }
    if (c === open) depth++;
    else if (c === close) { depth--; if (depth === 0) return i + 1; }
    i++;
  }
  throw new Error('unbalanced brackets');
}
const skipParens = (s, i) => skipGroup(s, i, '(', ')');

// ---------- generic passes ----------
function wrapCalls(src, regex, openOffsetFn, needsPrepareSkip) {
  const hits = [];
  let m; regex.lastIndex = 0;
  while ((m = regex.exec(src))) hits.push({ idx: m.index, len: m[0].length });
  for (const { idx, len } of hits.reverse()) {
    if (/await\s*$/.test(src.slice(Math.max(0, idx - 8), idx))) continue; // already awaited
    let end;
    if (needsPrepareSkip) {
      end = skipParens(src, idx + 'db.prepare'.length);
      const mm = /^\s*\.(get|all|run)\(/.exec(src.slice(end, end + 20));
      if (!mm) continue; // e.g. const stmt = db.prepare(...)  (kept lazy)
      end = skipParens(src, end + mm[0].length - 1);
    } else {
      end = skipParens(src, idx + len - 1);
    }
    src = src.slice(0, idx) + '(await ' + src.slice(idx, end) + ')' + src.slice(end);
  }
  return src;
}
export const awaitDbCalls = s => wrapCalls(s, /(?<![\w.$])db\.prepare\(/g, null, true);
export const awaitStmtCalls = s => wrapCalls(s, /(?<![\w.$])(?:getListing|logEvent|insertUser)\.(?:get|all|run)\(/g, null, false);
export const asyncHandlers = s => s.replace(/(?<!async)(?<!async )\(\s*_?req\s*,\s*res\s*(?:,\s*next\s*)?\)\s*=>/g, m => 'async ' + m);

// ---------- main ----------
function main() {
  const file = process.argv[2] || 'server.js';
  if (!fs.existsSync(file)) { console.error(`Cannot find ${file}. Run this from the project root.`); process.exit(1); }
  const original = fs.readFileSync(file, 'utf8');
  if (original.includes("./server/db.js")) { console.log('server.js already uses PostgreSQL. Nothing to do.'); return; }
  if (!fs.existsSync('server/db.js') || !fs.existsSync('server/sql-translate.js')) {
    console.error('Missing server/db.js or server/sql-translate.js. Copy them into the project first.'); process.exit(1);
  }
  let src = original.replace(/\r\n/g, '\n');

  const exact = (find, repl, expected = 1) => {
    const n = src.split(find).length - 1;
    if (n !== expected) throw new Error(`Expected ${expected} match(es) but found ${n} for:\n  ${find.slice(0, 110)}`);
    src = src.split(find).join(repl);
  };
  const rx = (re, repl, label, min = 1) => {
    const n = (src.match(re) || []).length;
    if (n < min) throw new Error(`Pattern not found: ${label}`);
    src = src.replace(re, repl);
  };

  // 1. imports, database creation, session store
  exact("import SQLiteStoreFactory from 'connect-sqlite3';\nimport Database from 'better-sqlite3';\n",
        "import 'express-async-errors';\nimport PgStoreFactory from 'connect-pg-simple';\nimport { db, pool } from './server/db.js';\n");
  exact("const db = new Database(path.join(dataDir, 'haatbazar.sqlite'));\ndb.pragma('journal_mode = WAL');\ndb.pragma('foreign_keys = ON');\ndb.exec(`",
        "await db.exec(`");
  exact('const SQLiteStore = SQLiteStoreFactory(session);', 'const PgStore = PgStoreFactory(session);');
  exact("store: new SQLiteStore({ db: 'sessions.sqlite', dir: dataDir, concurrentDB: true }),",
        "store: new PgStore({ pool, tableName: 'session', createTableIfMissing: true }),");

  // 2. schema dialect (only inside the big CREATE TABLE block)
  const start = src.indexOf('await db.exec(`');
  const end = src.indexOf('`);', start);
  if (start < 0 || end < 0) throw new Error('Schema block not found');
  let schema = src.slice(start, end);
  schema = schema.replace(/INTEGER PRIMARY KEY AUTOINCREMENT/g, 'SERIAL PRIMARY KEY')
                 .replace(/\bREAL\b/g, 'DOUBLE PRECISION')
                 .replace(/expires_at INTEGER/g, 'expires_at BIGINT')
                 .replace('INSERT OR IGNORE INTO marketing_settings(id,spend_bdt) VALUES(1,0);',
                          'INSERT INTO marketing_settings(id,spend_bdt) VALUES(1,0) ON CONFLICT DO NOTHING;');
  if (schema.includes('INSERT OR IGNORE') || schema.includes('AUTOINCREMENT')) throw new Error('Schema conversion incomplete');
  src = src.slice(0, start) + schema + src.slice(end);

  // 3. helper functions
  rx(/function ensureColumn\([^)]*\) \{[\s\S]*?\n\}\n/,
     "async function ensureColumn(table, column, definition) {\n await db.exec(`ALTER TABLE ${table} ADD COLUMN IF NOT EXISTS ${column} ${definition}`);\n}\n",
     'ensureColumn');
  rx(/^ensureColumn\(/gm, 'await ensureColumn(', 'ensureColumn calls');
  exact("'REAL NOT NULL DEFAULT 0'", "'DOUBLE PRECISION NOT NULL DEFAULT 0'");
  rx(/function event\(req, type, listingId, category, metadata = \{\}\) \{[\s\S]*?\n\}\n/,
     "async function event(req, type, listingId, category, metadata = {}) {\n  try {\n    const visitorId = String(req.headers['x-visitor-id'] || req.sessionID || '').slice(0, 100);\n    await logEvent.run(type, listingId || null, category || null, visitorId, req.session.user?.id || null, JSON.stringify(metadata));\n  } catch (e) { console.error('event_log_failed', e?.message || e); }\n}\n",
     'event()');
  exact('const publicListing = row => {', 'const publicListing = async row => {');
  exact('const count=(sql,...args)=>db.prepare(sql).get(...args).n;', 'const count=async(sql,...args)=>(await db.prepare(sql).get(...args)).n;');
  rx(/\bcount\(/g, 'await count(', 'count() calls');
  exact('function seoIndex(req,res,next){', 'async function seoIndex(req,res,next){');

  // 4. transaction when creating a listing
  exact('const createListingTx = db.transaction(() => {', 'await db.transaction(async (db) => {');
  rx(/^\s*createListingTx\(\);\n/m, '', 'createListingTx()');

  // 5. places that build public listings (now async)
  exact('const recentListings=db.prepare("SELECT * FROM listings WHERE status=\'active\' ORDER BY created_at DESC LIMIT 8").all().map(publicListing);',
        'const recentListings=await Promise.all((await db.prepare("SELECT * FROM listings WHERE status=\'active\' ORDER BY created_at DESC LIMIT 8").all()).map(publicListing));');
  exact('res.json({items:rows.map(publicListing),total,page,limit});', 'res.json({items:await Promise.all(rows.map(publicListing)),total,page,limit});');
  exact('res.json({items:rows.map(publicListing)});', 'res.json({items:await Promise.all(rows.map(publicListing))});');
  exact('res.status(201).json(publicListing(getListing.get(id)));', 'res.status(201).json(await publicListing(await getListing.get(id)));');
  exact('res.json(publicListing(row));', 'res.json(await publicListing(row));');
  exact('const l=publicListing(row);', 'const l=await publicListing(row);');

  // 6. SQL that PostgreSQL is stricter about
  exact('GROUP BY e.listing_id ORDER BY views DESC LIMIT 10', 'GROUP BY e.listing_id,l.title ORDER BY views DESC LIMIT 10');
  exact('HAVING COUNT(*)>1)', 'HAVING COUNT(*)>1) t');

  // 7. await every database call, make handlers async
  src = awaitDbCalls(src);
  src = awaitStmtCalls(src);
  src = asyncHandlers(src);

  // 8. sanity warnings
  const warn = [];
  src.split('\n').forEach((line, i) => {
    if (/(?<!await )(?<![\w.$])db\.prepare\([^`]*?\)\.(get|all|run)\(/.test(line) ) warn.push(`line ${i + 1}: possible un-awaited db call`);
    if (/(?<!await )(?<!const )(?<!async )publicListing\(/.test(line)) warn.push(`line ${i + 1}: publicListing() without await`);
  });

  fs.writeFileSync(file + '.sqlite-backup', original);
  fs.writeFileSync(file, src);
  const check = spawnSync(process.execPath, ['--check', file], { encoding: 'utf8' });
  if (check.status !== 0) {
    fs.writeFileSync(file, original);
    console.error('Syntax check FAILED, server.js was restored. Send this error to Claude:\n' + check.stderr);
    process.exit(1);
  }

  // 9. package.json dependencies
  if (fs.existsSync('package.json')) {
    const pkg = JSON.parse(fs.readFileSync('package.json', 'utf8'));
    delete pkg.dependencies['better-sqlite3'];
    delete pkg.dependencies['connect-sqlite3'];
    Object.assign(pkg.dependencies, { 'connect-pg-simple': '^10.0.0', 'express-async-errors': '^3.1.1', pg: '^8.13.1' });
    pkg.dependencies = Object.fromEntries(Object.entries(pkg.dependencies).sort(([a], [b]) => a.localeCompare(b)));
    fs.writeFileSync('package.json', JSON.stringify(pkg, null, 2) + '\n');
  }

  console.log('Done. server.js now uses PostgreSQL. Backup: ' + file + '.sqlite-backup');
  if (warn.length) console.log('Please check:\n  ' + warn.join('\n  '));
  console.log('Next: run  npm install  and then commit + push to GitHub.');
}

if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  try { main(); } catch (e) { console.error('Migration stopped (nothing was changed):\n' + e.message); process.exit(1); }
}
