// PostgreSQL (Neon) adapter with a small better-sqlite3-like API:
//   await db.prepare(sql).get(...params)  -> first row or undefined
//   await db.prepare(sql).all(...params)  -> array of rows
//   await db.prepare(sql).run(...params)  -> { changes, lastInsertRowid }
//   await db.exec(sql)                    -> run schema / multi-statement SQL
//   await db.transaction(async (db) => { ... })
import pg from 'pg';
import { translate, fixRow } from './sql-translate.js';

const { Pool, types } = pg;
types.setTypeParser(20, v => Number(v));   // BIGINT / COUNT(*) -> JS number
types.setTypeParser(1700, v => Number(v)); // NUMERIC -> JS number

if (!process.env.DATABASE_URL) {
  throw new Error('DATABASE_URL is required (your Neon Postgres connection string)');
}

export const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  max: Number(process.env.PG_POOL_MAX || 5),
  idleTimeoutMillis: 30000,
  connectionTimeoutMillis: 20000, // Neon may need a moment to wake up
  keepAlive: true,
});
pool.on('error', err => console.error('Postgres pool error:', err.message));

function makeDb(query, isRoot) {
  const api = {
    prepare(sql) {
      return {
        get: async (...params) => fixRow((await query(translate(sql), params)).rows[0]),
        all: async (...params) => (await query(translate(sql), params)).rows.map(fixRow),
        run: async (...params) => {
          const r = await query(translate(sql), params);
          return { changes: r.rowCount, lastInsertRowid: r.rows?.[0]?.id };
        },
      };
    },
    exec: async sql => { await query(translate(sql)); },
  };
  if (isRoot) {
    api.transaction = async fn => {
      const client = await pool.connect();
      try {
        await client.query('BEGIN');
        const result = await fn(makeDb((t, p) => client.query(t, p), false));
        await client.query('COMMIT');
        return result;
      } catch (e) {
        try { await client.query('ROLLBACK'); } catch {}
        throw e;
      } finally {
        client.release();
      }
    };
  }
  return api;
}

export const db = makeDb((text, params) => pool.query(text, params), true);
