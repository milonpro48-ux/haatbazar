// Translates the SQLite-flavoured SQL used in server.js into PostgreSQL SQL.
// Pure functions only (no database needed), so it is easy to test.

export const NOW_SQL = "to_char(now() AT TIME ZONE 'UTC','YYYY-MM-DD HH24:MI:SS')";

// PostgreSQL folds unquoted column names to lower case; the app expects camelCase.
const KEYMAP = {
  sellername: 'sellerName',
  businessname: 'businessName',
  saletype: 'saleType',
  minorderquantity: 'minOrderQuantity',
  deliveryavailable: 'deliveryAvailable',
  listingtitle: 'listingTitle',
  listingid: 'listingId',
};

export function fixRow(row) {
  if (!row) return row;
  const out = {};
  for (const k of Object.keys(row)) out[KEYMAP[k] || k] = row[k];
  return out;
}

export function translate(sql) {
  let s = String(sql);
  // datetime('now','-7 days')  ->  text timestamp 7 days ago (UTC)
  s = s.replace(/datetime\('now'\s*,\s*'-(\d+)\s+(day|days|hour|hours|minute|minutes)'\)/gi,
    (_m, n, unit) => `to_char((now() AT TIME ZONE 'UTC') - interval '${n} ${unit}','YYYY-MM-DD HH24:MI:SS')`);
  s = s.replace(/datetime\('now'\)/gi, NOW_SQL);
  // SQLite LIKE is case-insensitive, PostgreSQL LIKE is not.
  s = s.replace(/\bLIKE\b/g, 'ILIKE');
  // The app needs the new user id back after inserting a user.
  if (/^\s*INSERT\s+INTO\s+users\b/i.test(s) && !/RETURNING/i.test(s)) s = s.replace(/;?\s*$/, ' RETURNING id');
  // ? placeholders -> $1, $2 ... (ignoring ? inside quoted strings)
  let out = '';
  let n = 0;
  let inQuote = false;
  for (let i = 0; i < s.length; i++) {
    const c = s[i];
    if (c === "'") { inQuote = !inQuote; out += c; }
    else if (c === '?' && !inQuote) out += '$' + (++n);
    else out += c;
  }
  return out;
}
